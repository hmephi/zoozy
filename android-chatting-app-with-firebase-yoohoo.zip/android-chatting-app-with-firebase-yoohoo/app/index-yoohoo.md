---
title: "Yoohoo Documentation"
keywords: 
sidebar: 
hide_sidebar: true
search: false
permalink: index.html
summary: These instructions will help you in setup server and mobile application.
---

{% include note.html content="Video guide for getting Debug SHA1 fingerprint is available, checkout [https://www.youtube.com/watch?v=OQl6Me2_gEA](https://www.youtube.com/watch?v=OQl6Me2_gEA)" %}

# Introduction
Yoohoo is real-time complete chatting app with groups and voice messages functionality. The user can send pictures, audio, video, contact detail, map location, voice messages, a user can create groups as well.

# Setup

1. ### Android
      ***Note: Phone Authentication or some other functionality will not work on emulator. Kindly use real physical device for testing.** 

      Before continuing make sure you have :-
      - **Firebase Account** [https://console.firebase.google.com](https://console.firebase.google.com)
      - **Firebase's Realtime Database is enabled.**  Use following security rule or use **Start in test mode**:
          ```
          {   
            "rules": {
              // only authenticated users can read or write to my Firebase
              ".read": "auth !== null",
              ".write": "auth !== null"   
            }
          }
          ```
      - **Firebase's Storage is enabled**
      - **Phone Auth is enabled in Sign-in method in Firebase's Authentication section**
      - **Sinch Account** [https://www.sinch.com/](https://www.sinch.com/)
      - **SHA-1 fingerprint of your machine** [https://cloud.google.com/solutions/mobile/mobile-firebase-app-engine-flexible#generating_a_sha-1_fingerprint_for_the_app](https://cloud.google.com/solutions/mobile/mobile-firebase-app-engine-flexible#generating_a_sha-1_fingerprint_for_the_app)

      After following the steps given below make sure you have values of all the following keys with you:
      - **applicationId**
      - **app_name**
      - **support_email**
      - **sinch_app_key**
      - **sinch_app_secret**
      - **sinch_app_environment** - set this to `clientapi.sinch.com` for production app
      - **onesignal_app_id** - follow https://app.onesignal.com/apps/new to add your app and obtain OneSignal app id

      **`ADMOB Enable`**
      **in app level build.gradle file**
      Configure your AdMob banner IDs in `ad_unit_id1` and `ad_unit_id2`. ad_unit_id1 is used on outer chat list screen and ad_unit_id2 is used inside chat page.
      Switch `ENABLE_ADMOB` to `true`
      Configure your AdMob App ID in meta tag with name "com.google.android.gms.ads.APPLICATION_ID" in AndroidManifest.xml file.
      Save changes and sync gradle.
      note: you will need to build the project at least once to be able to use build configurations. i.e. -> BuildConfig.ENABLE_ADMOB

      **`ADMOB Disable`**
      **in app level build.gradle file**
      Simply switch `ENABLE_ADMOB` boolean field to `false`.
      Remove meta tag with name "com.google.android.gms.ads.APPLICATION_ID" from AndroidManifest.xml file.
      Save changes and sync gradle.
      note: you will need to build the project at least once to be able to use build configurations. i.e. -> BuildConfig.ENABLE_ADMOB

      You will need to update above values in `app/build.gradle`

      **`Refactoring`**
      - Change the `applicationId` in `app/build.gradle`, set this to the package name you want to keep for your application e.g com.yoohoo
      - Use the same package name while setting up android app in Firebase in the next step.
      - Logo and placeholders used in app are png images which you will find in `app/src/main/res/drawable` folder.
      - To change the images in app simply replace the images at above mentioned location with your images.

      **`Firebase Setup`**
      - Create a Firebase account or log into an existing account.

      - Click **Add project**. Follow the remaining setup steps and click **Create project**.
      <p align="center"><img src="{{ "images/8.1-firebase-create-project.png" }}"/></p>

      - After the wizard provisions your project, click Continue.

      - In the Overview page of your project, click the Settings gear and then click Project settings.

      - Click Add Firebase to your Android app and follow the wizard
      <p align="center"><img src="{{ "images/8.3-firebase-add-android-app.png" }}"/></p>

      - In Debug signing certificate SHA-1, enter the SHA-1 value you generated in the previous section.

      - Click Register app.

      - Download the google-services.json file and place it in `app` folder.
      <p align="center"><img src="{{ "images/8.4-firebase-download-config-json.png" }}"/></p>

      - Click Next in the Download config file section and follow the rest of the steps if required.

      - Next click on **Authentication** and click on **Sign-in method**
      <p align="center"><img src="{{ "images/8.5-firebase-sign-in-method.png" }}"/></p>

      - Enable **Phone Authentication**

      - Similarly enable **Realtime Database** and **Storage** from side menu.

      **`Configuration`** and **`Theming`**
      - Open `app/build.gradle`, you need to edit/add values in respective fields in `defaultConfig` under `android`
      - Fill in `applicationId` with your package name which you registered on firebase console
      - Fill in `app_name` and `support_email` with your desired app name and support email
      - For audio and video calling follow https://portal.sinch.com/#/signup to register your app name. Follow on screen instructions to obtain App Key and App Secret. Fill in these values in `sinch_app_key` and `sinch_app_secret` respectively. Finally setup `sinch_app_environment` configuration according to your sinch portal.
      - For notifications follow https://app.onesignal.com/apps/new to add your app and obtain OneSignal app id which will be used in `onesignal_app_id` under `manifestPlaceholders`.
      - We provide scope for customization of following values:

            resValue 'color', "colorPrimary", "#2196F3"
            resValue 'color', "colorPrimaryDark", "#1976D2"
            resValue 'color', "colorAccent", "#1A237E"

      **`Useful links`**
      - SHA-1 key related
        - [https://cloud.google.com/solutions/mobile/mobile-firebase-app-engine-flexible#generating_a_sha-1_fingerprint_for_the_app](https://cloud.google.com/solutions/mobile/mobile-firebase-app-engine-flexible#generating_a_sha-1_fingerprint_for_the_app)
        - [https://developers.google.com/android/guides/client-auth](https://developers.google.com/android/guides/client-auth)
        - [https://medium.com/pen-bold-kiln-press/sha-1-android-studio-ec02fb893e72](https://medium.com/pen-bold-kiln-press/sha-1-android-studio-ec02fb893e72)

**Note: If you are unable to understand any topic or find any topic needs more elaboration. 
Please raise an issue ticket at this link [https://opuslabs.freshdesk.com](https://opuslabs.freshdesk.com)**
