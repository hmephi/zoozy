package com.verbosetech.yoohoo.utils;

import androidx.core.content.FileProvider;

/**
 * Created by a_man on 5/15/2017.
 */

public class MyFileProvider extends FileProvider {
}
